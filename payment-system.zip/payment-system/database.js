const Database = require('better-sqlite3');
const db = new Database('payments.db');

db.exec(`
  CREATE TABLE IF NOT EXISTS payment_methods (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    type TEXT NOT NULL,          -- bank | crypto | giftcard
    label TEXT,                  -- e.g. "Opay - Nkechi"
    bank_name TEXT,
    account_name TEXT,
    account_number TEXT,
    crypto_address TEXT,
    crypto_network TEXT,         -- TRC20, ERC20, etc
    giftcard_info TEXT,
    active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    price INTEGER NOT NULL,     -- Naira
    credits INTEGER NOT NULL,
    description TEXT,
    active INTEGER DEFAULT 1
  );

  CREATE TABLE IF NOT EXISTS orders (
    id TEXT PRIMARY KEY,
    reference TEXT UNIQUE,
    email TEXT,
    telegram_id TEXT,
    product_id INTEGER,
    amount INTEGER,
    credits INTEGER,
    payment_type TEXT,
    payment_detail TEXT,         -- JSON snapshot of the method shown
    status TEXT DEFAULT 'pending', -- pending | paid | rejected
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    paid_at DATETIME
  );

  CREATE TABLE IF NOT EXISTS users (
    email TEXT PRIMARY KEY,
    telegram_id TEXT,
    credits INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

// Seed payment methods if empty
const methodCount = db.prepare('SELECT COUNT(*) as c FROM payment_methods').get().c;
if (methodCount === 0) {
  const ins = db.prepare(`
    INSERT INTO payment_methods (type, label, bank_name, account_name, account_number, crypto_address, crypto_network, active)
    VALUES (?, ?, ?, ?, ?, ?, ?, 1)
  `);

  // Banks
  ins.run('bank', 'Opay - Nkechi Modester', 'Opay', 'Nkechi Modester mba', '813499551', null, null);
  ins.run('bank', 'Opay - Chikamso', 'Opay', 'Chikamso ODILI', '9137450015', null, null);
  ins.run('bank', 'Zenith - Nkechi David', 'Zenith', 'Nkechi David', '2547411525', null, null);

  // Crypto
  ins.run('crypto', 'USDT TRC20', null, null, null, 'TXYUStZaFp37cSo7vNGqHBc1nPdKtvVeUT', 'TRC20');
}

// Seed products if empty
const prodCount = db.prepare('SELECT COUNT(*) as c FROM products').get().c;
if (prodCount === 0) {
  const p = db.prepare(`INSERT INTO products (name, price, credits, description) VALUES (?, ?, ?, ?)`);
  p.run('1 AI Credit', 500, 1, '₦500 = 1 AI Credit');
  p.run('5 AI Credits', 2000, 5, 'Best starter pack');
  p.run('20 AI Credits', 7000, 20, 'Most popular');
  p.run('50 AI Credits', 15000, 50, 'Power pack');
}

module.exports = db;
