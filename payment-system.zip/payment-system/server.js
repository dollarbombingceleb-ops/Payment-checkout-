require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const { v4: uuidv4 } = require('uuid');
const db = require('./database');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());

// ---------- TELEGRAM BOT ----------
let bot = null;
const BOT_TOKEN = process.env.BOT_TOKEN;
const ADMIN_TG = process.env.ADMIN_TELEGRAM_ID ? String(process.env.ADMIN_TELEGRAM_ID) : null;

if (BOT_TOKEN) {
  try {
    const { Telegraf, Markup } = require('telegraf');
    bot = new Telegraf(BOT_TOKEN);

    bot.start((ctx) => {
      ctx.reply(
        '🤖 Payment Bot ready.\n\n' +
        'Commands:\n' +
        '/pending – list pending payments\n' +
        '/help – show help'
      );
    });

    bot.command('help', (ctx) => {
      ctx.reply(
        'Commands:\n' +
        '/pending – show pending orders\n' +
        '/confirm PAY-XXXXXX – confirm a payment\n' +
        '/balance email@example.com – check user credits'
      );
    });

    bot.command('pending', async (ctx) => {
      if (ADMIN_TG && String(ctx.from.id) !== ADMIN_TG) {
        return ctx.reply('Not authorized.');
      }
      const orders = db.prepare(`
        SELECT * FROM orders WHERE status = 'pending' ORDER BY created_at DESC LIMIT 15
      `).all();
      if (!orders.length) return ctx.reply('No pending payments.');

      for (const o of orders) {
        const detail = JSON.parse(o.payment_detail || '{}');
        let payInfo = o.payment_type;
        if (detail.account_number) payInfo = `${detail.bank_name} – ${detail.account_number}`;
        if (detail.crypto_address) payInfo = `USDT ${detail.crypto_network || ''} – ${detail.crypto_address.slice(0, 16)}...`;

        await ctx.reply(
          `⏳ *Pending*\n` +
          `Ref: \`${o.reference}\`\n` +
          `Email: ${o.email}\n` +
          `Amount: ₦${Number(o.amount).toLocaleString()}\n` +
          `Credits: ${o.credits}\n` +
          `Method: ${payInfo}\n` +
          `Time: ${o.created_at}`,
          {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([
              Markup.button.callback('✅ Confirm', `confirm:${o.reference}`),
              Markup.button.callback('❌ Reject', `reject:${o.reference}`)
            ])
          }
        );
      }
    });

    bot.command('confirm', async (ctx) => {
      if (ADMIN_TG && String(ctx.from.id) !== ADMIN_TG) {
        return ctx.reply('Not authorized.');
      }
      const parts = ctx.message.text.split(' ');
      const ref = parts[1];
      if (!ref) return ctx.reply('Usage: /confirm PAY-XXXXXX');
      const result = await confirmOrder(ref);
      ctx.reply(result.message);
    });

    bot.command('balance', async (ctx) => {
      const email = ctx.message.text.split(' ')[1];
      if (!email) return ctx.reply('Usage: /balance email@example.com');
      const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email.toLowerCase());
      if (!user) return ctx.reply('User not found.');
      ctx.reply(`${user.email}\nCredits: ${user.credits}`);
    });

    bot.action(/confirm:(.+)/, async (ctx) => {
      if (ADMIN_TG && String(ctx.from.id) !== ADMIN_TG) {
        return ctx.answerCbQuery('Not authorized');
      }
      const ref = ctx.match[1];
      const result = await confirmOrder(ref);
      await ctx.answerCbQuery(result.message);
      await ctx.editMessageText(ctx.callbackQuery.message.text + `\n\n✅ CONFIRMED`);
    });

    bot.action(/reject:(.+)/, async (ctx) => {
      if (ADMIN_TG && String(ctx.from.id) !== ADMIN_TG) {
        return ctx.answerCbQuery('Not authorized');
      }
      const ref = ctx.match[1];
      db.prepare(`UPDATE orders SET status='rejected' WHERE reference=?`).run(ref);
      await notifyWebhook({ event: 'payment.rejected', reference: ref });
      await ctx.answerCbQuery('Rejected');
      await ctx.editMessageText(ctx.callbackQuery.message.text + `\n\n❌ REJECTED`);
    });

    bot.launch().then(() => console.log('Telegram bot started')).catch(e => {
      console.error('Bot start failed:', e.message);
    });

    process.once('SIGINT', () => bot.stop('SIGINT'));
    process.once('SIGTERM', () => bot.stop('SIGTERM'));
  } catch (e) {
    console.error('Telegraf not available yet. Run npm install. Bot disabled for now.');
  }
}

// ---------- HELPERS ----------
function randomMethod(type) {
  const rows = db.prepare('SELECT * FROM payment_methods WHERE type = ? AND active = 1').all(type);
  if (!rows.length) return null;
  return rows[Math.floor(Math.random() * rows.length)];
}

function makeReference() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let ref = 'PAY-';
  for (let i = 0; i < 6; i++) ref += chars[Math.floor(Math.random() * chars.length)];
  return ref;
}

async function notifyWebhook(payload) {
  const url = process.env.WEBHOOK_URL;
  if (!url) return;
  try {
    await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
  } catch (e) {
    console.error('Webhook failed:', e.message);
  }
}

async function notifyTelegramAdmin(text, reference) {
  if (!bot || !ADMIN_TG) return;
  try {
    const { Markup } = require('telegraf');
    await bot.telegram.sendMessage(
      ADMIN_TG,
      text,
      {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
          Markup.button.callback('✅ Confirm', `confirm:${reference}`),
          Markup.button.callback('❌ Reject', `reject:${reference}`)
        ])
      }
    );
  } catch (e) {
    console.error('TG notify failed:', e.message);
  }
}

async function confirmOrder(reference) {
  const order = db.prepare('SELECT * FROM orders WHERE reference = ?').get(reference);
  if (!order) return { ok: false, message: 'Order not found' };
  if (order.status === 'paid') return { ok: true, message: 'Already paid' };

  db.prepare(`UPDATE orders SET status='paid', paid_at=CURRENT_TIMESTAMP WHERE reference=?`)
    .run(reference);

  let user = db.prepare('SELECT * FROM users WHERE email = ?').get(order.email);
  if (!user) {
    db.prepare('INSERT INTO users (email, telegram_id, credits) VALUES (?, ?, 0)')
      .run(order.email, order.telegram_id || null);
  }
  db.prepare('UPDATE users SET credits = credits + ? WHERE email = ?')
    .run(order.credits, order.email);

  await notifyWebhook({
    event: 'payment.confirmed',
    reference: order.reference,
    email: order.email,
    telegram_id: order.telegram_id,
    credits: order.credits,
    amount: order.amount
  });

  return { ok: true, message: `Confirmed. +${order.credits} credits to ${order.email}` };
}

// ---------- PUBLIC API ----------
app.get('/api/products', (req, res) => {
  res.json(db.prepare('SELECT * FROM products WHERE active = 1 ORDER BY price').all());
});

app.get('/api/payment-types', (req, res) => {
  res.json(db.prepare(`SELECT type, COUNT(*) as count FROM payment_methods WHERE active = 1 GROUP BY type`).all());
});

app.post('/api/checkout', async (req, res) => {
  try {
    const { email, product_id, payment_type, telegram_id } = req.body;
    if (!email || !product_id || !payment_type) {
      return res.status(400).json({ error: 'email, product_id and payment_type required' });
    }

    const product = db.prepare('SELECT * FROM products WHERE id = ? AND active = 1').get(product_id);
    if (!product) return res.status(404).json({ error: 'Product not found' });

    const method = randomMethod(payment_type);
    if (!method) return res.status(400).json({ error: 'No active ' + payment_type + ' methods available' });

    const orderId = uuidv4();
    const reference = makeReference();
    const detail = {
      type: method.type,
      label: method.label,
      bank_name: method.bank_name,
      account_name: method.account_name,
      account_number: method.account_number,
      crypto_address: method.crypto_address,
      crypto_network: method.crypto_network,
      giftcard_info: method.giftcard_info
    };

    db.prepare(`
      INSERT INTO orders (id, reference, email, telegram_id, product_id, amount, credits, payment_type, payment_detail)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      orderId, reference, email.toLowerCase().trim(), telegram_id || null,
      product.id, product.price, product.credits, payment_type, JSON.stringify(detail)
    );

    const payload = {
      event: 'payment.pending',
      reference,
      email: email.toLowerCase().trim(),
      telegram_id: telegram_id || null,
      amount: product.price,
      credits: product.credits,
      product: product.name,
      payment_type,
      payment_detail: detail
    };

    await notifyWebhook(payload);

    // Notify you on Telegram with Confirm / Reject buttons
    let payInfo = payment_type;
    if (detail.account_number) payInfo = `${detail.bank_name} – ${detail.account_number}`;
    if (detail.crypto_address) payInfo = `USDT ${detail.crypto_network || ''} – ${detail.crypto_address}`;

    await notifyTelegramAdmin(
      `⏳ *New pending payment*\n` +
      `Ref: \`${reference}\`\n` +
      `Email: ${email}\n` +
      `Amount: ₦${Number(product.price).toLocaleString()}\n` +
      `Credits: ${product.credits}\n` +
      `Method: ${payInfo}`,
      reference
    );

    res.json({
      reference,
      amount: product.price,
      credits: product.credits,
      product_name: product.name,
      payment: detail
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/order/:reference', (req, res) => {
  const order = db.prepare(`
    SELECT o.*, p.name as product_name FROM orders o
    LEFT JOIN products p ON o.product_id = p.id
    WHERE o.reference = ?
  `).get(req.params.reference);
  if (!order) return res.status(404).json({ error: 'Not found' });
  order.payment_detail = JSON.parse(order.payment_detail || '{}');
  res.json(order);
});

// ---------- ADMIN ----------
function adminAuth(req, res, next) {
  if (req.headers['x-admin-password'] !== process.env.ADMIN_PASSWORD) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  next();
}

app.get('/api/admin/stats', adminAuth, (req, res) => {
  res.json({
    pending: db.prepare("SELECT COUNT(*) as c FROM orders WHERE status='pending'").get().c,
    paid: db.prepare("SELECT COUNT(*) as c FROM orders WHERE status='paid'").get().c,
    revenue: db.prepare("SELECT COALESCE(SUM(amount),0) as s FROM orders WHERE status='paid'").get().s,
    methods: db.prepare('SELECT COUNT(*) as c FROM payment_methods WHERE active=1').get().c
  });
});

app.get('/api/admin/orders', adminAuth, (req, res) => {
  const orders = db.prepare(`
    SELECT o.*, p.name as product_name FROM orders o
    LEFT JOIN products p ON o.product_id = p.id
    ORDER BY o.created_at DESC LIMIT 100
  `).all();
  orders.forEach(o => { o.payment_detail = JSON.parse(o.payment_detail || '{}'); });
  res.json(orders);
});

app.post('/api/admin/orders/:reference/confirm', adminAuth, async (req, res) => {
  const result = await confirmOrder(req.params.reference);
  res.json(result);
});

app.post('/api/admin/orders/:reference/reject', adminAuth, async (req, res) => {
  db.prepare(`UPDATE orders SET status='rejected' WHERE reference=?`).run(req.params.reference);
  await notifyWebhook({ event: 'payment.rejected', reference: req.params.reference });
  res.json({ success: true });
});

app.get('/api/admin/methods', adminAuth, (req, res) => {
  res.json(db.prepare('SELECT * FROM payment_methods ORDER BY type, id').all());
});

app.post('/api/admin/methods', adminAuth, (req, res) => {
  const { type, label, bank_name, account_name, account_number, crypto_address, crypto_network, giftcard_info } = req.body;
  const r = db.prepare(`
    INSERT INTO payment_methods (type, label, bank_name, account_name, account_number, crypto_address, crypto_network, giftcard_info)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(type, label || '', bank_name || null, account_name || null, account_number || null,
         crypto_address || null, crypto_network || null, giftcard_info || null);
  res.json({ id: r.lastInsertRowid });
});

app.put('/api/admin/methods/:id', adminAuth, (req, res) => {
  const { label, bank_name, account_name, account_number, crypto_address, crypto_network, giftcard_info, active } = req.body;
  db.prepare(`
    UPDATE payment_methods SET
      label=?, bank_name=?, account_name=?, account_number=?,
      crypto_address=?, crypto_network=?, giftcard_info=?, active=?
    WHERE id=?
  `).run(label, bank_name, account_name, account_number, crypto_address, crypto_network,
         giftcard_info, active ? 1 : 0, req.params.id);
  res.json({ success: true });
});

app.delete('/api/admin/methods/:id', adminAuth, (req, res) => {
  db.prepare('DELETE FROM payment_methods WHERE id=?').run(req.params.id);
  res.json({ success: true });
});

app.get('/api/admin/products', adminAuth, (req, res) => {
  res.json(db.prepare('SELECT * FROM products ORDER BY price').all());
});

app.post('/api/admin/products', adminAuth, (req, res) => {
  const { name, price, credits, description } = req.body;
  const r = db.prepare(`INSERT INTO products (name, price, credits, description) VALUES (?, ?, ?, ?)`)
    .run(name, Number(price), Number(credits), description || '');
  res.json({ id: r.lastInsertRowid });
});

app.put('/api/admin/products/:id', adminAuth, (req, res) => {
  const { name, price, credits, description, active } = req.body;
  db.prepare(`UPDATE products SET name=?, price=?, credits=?, description=?, active=? WHERE id=?`)
    .run(name, Number(price), Number(credits), description || '', active ? 1 : 0, req.params.id);
  res.json({ success: true });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`\nPayment system: http://localhost:${PORT}`);
  console.log(`Admin: http://localhost:${PORT}/admin.html`);
  if (BOT_TOKEN) console.log('Telegram bot: enabled');
  else console.log('Telegram bot: no BOT_TOKEN set');
  console.log('');
});
